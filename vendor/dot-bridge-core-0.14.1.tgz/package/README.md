# dot-bridge-core

[简体中文](README.zh-CN.md) · [English](README.md)

Canonical provider-independent shared code for the existing dot bridges. Node
>=24.15 and <25. The repository builds the versioned `@dot-bridge/core` package;
deployments install its reviewed tarball without cloning this source repository.
No IM SDK, model API, credentials, database, callback subscription or Tunnel
runtime key is included in this package.

Exports:

- `@dot-bridge/core/transport`: the existing strict callback transport.
- `@dot-bridge/core/platform`: Windows native handles and mode locks.
- `@dot-bridge/core/platform/private-files.js`: canonical descriptor-relative Linux
  private file/database leases and the matching Windows branch, also used by
  standalone deployment status and backup validation scripts.
- `@dot-bridge/core/router`: registered-channel loopback MCP aggregation.
- `@dot-bridge/core/audio`: optional local speech transcription for hosts that
  cannot consume native MCP audio.
- `@dot-bridge/core/audio/silk.js`: isolated bounded SILK decoding and PCM WAV
  encoding using a codec explicitly pinned by the provider.
- `@dot-bridge/core/channels/pairing.js`: expiring owner pairing and private,
  no-overwrite credential installation for dedicated enrollment commands.
- `@dot-bridge/core/channels`: shared runtime for new independent IM providers:
  owner-bound MCP tools/events, encrypted SQLite inbox and outbox, callback
  verification, service authentication and graceful process lifecycle.

The runtime defaults to the bound owner private chat. Telegram and Discord may
opt into protected group/topic rules with independent context scopes. It persists polling state and queues before acknowledging messages, and
keeps uncertain callback/reply attempts without automatically resending them.

Supported media channels also provide source-attachment replies: dot can reuse
the current message's attachment by index without reconstructing Base64. Text
files include bounded UTF-8/UTF-16 excerpts with explicit truncation; the original
bytes remain available. Provider format and caption limits still apply.

The shared runtime also provides encrypted, source-bound generated-file uploads,
native choice dispatch for capable providers, and reminder pause/resume/history.
Reminder schedules include weekdays and bounded fixed intervals. Native choices
bind to the original actor, chat and topic and persist before acknowledgement.
Each channel supplies only its platform protocol implementation, following the
[provider contract](docs/channel-provider-contract.md). Media-capable providers
expose bounded attachment reads and a single final text or media reply. Private
download references remain encrypted, and authorization is checked again before
each stage of a media send. Setup tools expose redacted subscription diagnostics.

## Tasks and conversation queues

`begin_<channel>_task` records actual work and its remaining passive reply time.
`save_<channel>_task_result` stores one complete text result, including after that
window ends. `get_<channel>_task_result` reads it through the original active
subscription. The paired owner can use `/tasks` and `/result <reference>` in the
original private chat. Results use the existing encrypted database and retention
period. A fresh result query uses that new message's ordinary reply mechanism.

Protected shared-channel interaction policies accept `queue.mode` values
`independent` (default), `serial`, and `batch`. Batch mode combines plain-text
inputs within `queue.window_ms` (0–3000, default 750), bounded by
`queue.max_messages` (2–20, default 5). Each source remains stored with its own
identifier and the shared reply outcome. The last source anchors the reply.
Conversation, topic and configured sender context determine the batch boundary.
Attachments, quotations and work already being processed retain separate replies.

LINE providers can use authenticated native postbacks whose source receipt is
confirmed by the reply API. Every choice remains bound to its original sender,
private chat, expiring token and durable first selection.

MCP attachment reads and replies are limited to 5 MiB per original file. Base64,
duplicated transcript metadata and the official Tunnel envelope consume additional
space; the raw file limit is not the Tunnel's serialized 10 MiB limit. Providers
may impose smaller format-specific bounds. Pre-upgrade oversized queued media is
kept encrypted and pending without a send attempt. Resolve outstanding work before
upgrading, or recover it with the previous compatible release; never delete a
queue or automatically resend an uncertain reply to make an upgrade pass.

Authenticated setup/readiness tools expose optional subscription expiry,
connection-stage advice, callback-setting presence/counts and complete durable
reply-work counts. Expiry comes only from stored subscription data. Empty
diagnostic history means the prior failure cannot be reconstructed; it does not
prove that no request reached the bridge. Older backends without these fields
remain supported and must be displayed as unknown rather than inferred ready.

Subscriptions expire after at most seven days. The original dot must renew them
before the returned `refreshBefore`; the bridge cannot independently renew a
host-owned subscription. An inactive subscription pauses callback and reply
delivery. Pending messages remain available until their reply deadline.

Message records are logically removed after seven days. SQLite pages, WAL,
backups and system logs may retain old bytes; this policy is not physical erasure.

The executable in each IM repository registers its trusted adapter in code. The
adapter owns tool/event schemas, argument and result projection, capabilities,
per-tool budgets and provider preflight details. The router does not fetch or load
modules described by callers or environment variables. It never forwards upstream
descriptions, credentials, identities or arbitrary errors.

`TUNNEL_CHANNELS` selects installed adapters (default: all explicitly registered
by that executable). `TUNNEL_LIVE_CHANNELS` is an independently validated subset.
Omitted adapters require no key, port, readiness service or network connection.
Ingress and every configured upstream use separate service keys. All targets
remain fixed loopback endpoints. Official Tunnel and dot subscription management
remain external to core; no model API bot or replacement Tunnel is created.

For standalone Feishu, its executable registers only `lark`. Install the Feishu
repository with its lockfile and included core tarball, then run:

```sh
npm ci --omit=dev --ignore-scripts --no-audit --no-fund
node --env-file=/protected/router.env scripts/run-tunnel-router.js --confirm-live
```

For development and offline regression in this repository:

```sh
npm ci --omit=dev --ignore-scripts --no-audit --no-fund
npm run check
npm test
npm pack --ignore-scripts
```

Private ownership checks, direct HTTPS/DNS/IP pinning, original-host TLS checks,
no redirects, no automatic mutation retry and uncertain-delivery behavior are
preserved. Installed copies are immutable releases of one canonical source;
consuming repositories must not maintain separate shared implementations.

Local transcription is opt-in and currently requires Linux. Install a reviewed
`whisper-cli` build and a multilingual Whisper model from the upstream
[whisper.cpp project](https://github.com/ggml-org/whisper.cpp). Keep the executable,
model and parent directories root-owned and not writable by the service user.
The backend environment selects them with `DOT_BRIDGE_AUDIO_TRANSCRIPTION=local-whisper`,
`DOT_BRIDGE_WHISPER_BINARY=/protected/runtime/whisper-cli` and
`DOT_BRIDGE_WHISPER_MODEL=/protected/runtime/ggml-base.bin`.
Build the included `audio/no-core-dump.c` with
`cc -shared -fPIC -O2 -o /protected/runtime/no-core-dump.so audio/no-core-dump.c`
and set `DOT_BRIDGE_AUDIO_GUARD=/protected/runtime/no-core-dump.so`. It must have
the same root-owned protection. This constructor makes each audio subprocess
nondumpable after exec; a zero core-size limit alone is insufficient on systems
with piped crash collectors. Missing protection makes transcription unavailable.
Use the existing private `BRIDGE_LOCK_DIRECTORY` across enabled backends; one
nonblocking lock serializes recognition across them. FFmpeg, prlimit and flock
must be installed under `/usr/bin`. No API key or external transcription
service is used. The host's original dot still generates the response.

Audio travels through bounded memory pipes, never a temporary media file.
Recognition uses one CPU thread, a virtual address-space ceiling of 1.5 GiB and at most
28 seconds of wall time. The transcription primitive accepts up to 8 MiB and 120 seconds; channel attachment RPCs retain their stricter 5 MiB limit. Decoded
silence, busy/absent runtimes, unsupported formats and timeouts return
`extraction_status:unsupported`. The bridge keeps the native audio result and
must ask for clearer/shorter speech or text when neither audio nor transcription
is usable. Reference transcription can contain errors and is untrusted content.
Runtime programs receive no application credentials or proxy environment.

`provenance/extraction.json` records the reviewed source revision and unchanged
shared file hashes. Provider-specific contracts now belong to their IM adapters.
Actual adapter/router integration runs in the Feishu repository without optional
sibling-path skips. The QQ repository retains thin two-adapter compatibility
exports and regression fixtures for the old finite-window development launcher;
these are not required by Feishu or the persistent VPS deployment.

Shared interaction modules add bounded processing feedback, genuine progressive edits, isolated recent context, safe Markdown rendering, protected PDF/Office excerpts, durable native reply parts and owner IM management. Hosted-dot controls remain on the original platform.

[简体中文](README.zh-CN.md) · [English](README.md)


## Processing and final delivery

`begin_<channel>_task`, `save_<channel>_task_result` and `get_<channel>_task_result` retain and retrieve a generated text result in encrypted state after the passive reply deadline. The paired owner can use `/tasks` and `/result <reference>`. Retention follows the source record. An explicit known provider rejection can be retried with `retry_<channel>_outbound`, its current revision and `confirm=true`; ambiguous sends stay uncertain.

The protected interaction policy accepts `queue.mode` of `independent`, `serial` or `batch`, `window_ms` from 0 to 3000 and `max_messages` from 2 to 20. The default is independent. Only unread plain-text sources in the same conversation, topic, sender scope and subscription generation can be combined. Every source remains stored and points to one anchor and outcome. QQ and Lark use the shared legacy queue adapter over their existing stores.

Optional local speech uses `DOT_BRIDGE_SPEECH_SYNTHESIS=local-espeak` and `DOT_BRIDGE_SPEECH_VOICE=zh`, the existing protected audio guard and shared audio lock. Install root-owned `/usr/bin/espeak-ng`, FFmpeg, prlimit and flock on Linux. `check_<channel>_speech` reports runtime readiness and delivery type. `reply_<channel>_speech` accepts up to 2000 characters and 120 seconds and retains the full text result. QQ/Weixin use native voice, Lark/Telegram use Opus, Discord can use its native voice attachment, LINE uses MP3, and DingTalk/WeCom receive a WAV file. Provider media settings still apply.

The authenticated loopback `/runtime` endpoint reports the actual source SHA, package version and catalog fingerprint. GitHub/Git archives expand `source-revision.txt`; packages include that public provenance file. Operators compare the running catalog with the installed catalog and separately refresh the original dot's loaded plugin directory.

For the shared channel runtime, `get_<channel>_reply_status` reports final delivery. It remains `none` during a typing/processing lease until a final answer is queued. `begin`/`append` can report the separate processing lifecycle; finalize the current flow once. An ambiguous native progress write remains `uncertain`. Telegram/Discord append cumulative text; the established Lark adapter appends deltas. See the [provider contract](docs/channel-provider-contract.md).

Protected PDF/Office extraction uses the packaged `audio/read-document.py` worker through root-owned Python/prlimit and the existing guard. The reviewed public runtime tree, including that worker, must be root-owned and service-user read-only; private data remains owned by the service account. The host supplies Python 3 with `pypdf` for PDF text. The bounded worker keeps original attachments available when extraction is unavailable.
